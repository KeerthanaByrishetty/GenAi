import React, { useEffect, useState } from 'react';
import { getAllClaims, getPolicyDetails } from './services/claimService'; // Add getPolicyDetails function

const ClaimsList = () => {
  const [claims, setClaims] = useState([]);
  const [policyNumber, setPolicyNumber] = useState('');
  const [policyDetails, setPolicyDetails] = useState(null);

  useEffect(() => {
    const fetchClaims = async () => {
      const data = await getAllClaims();
      setClaims(data);
    };
    fetchClaims();
  }, []);

  const handleFetchPolicyDetails = async () => {
    if (policyNumber.trim() === '') {
      alert('Please enter a policy number.');
      return;
    }
    try {
      const details = await getPolicyDetails(policyNumber);
      setPolicyDetails(details);
    } catch (error) {
      console.error('Error fetching policy details:', error);
      alert('Failed to fetch policy details. Please try again.');
    }
  };

  return (
    <div>
      <h1>Claims List</h1>
      <div>
        <input
          type="text"
          placeholder="Enter Policy Number"
          value={policyNumber}
          onChange={(e) => setPolicyNumber(e.target.value)}
        />
        <button onClick={handleFetchPolicyDetails}>Fetch Policy Details</button>
      </div>
      {policyDetails && (
        <div>
          <h2>Policy Details</h2>
          <p><strong>Policy Number:</strong> {policyDetails.policyNumber}</p>
          <p><strong>Policy Holder:</strong> {policyDetails.policyHolderName}</p>
          <p><strong>Start Date:</strong> {policyDetails.policyStartDate}</p>
          <p><strong>End Date:</strong> {policyDetails.policyEndDate}</p>
        </div>
      )}
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Policy Number</th>
            <th>Policy Holder</th>
            <th>Start Date</th>
            <th>End Date</th>
          </tr>
        </thead>
        <tbody>
          {claims.map((claim) => (
            <tr key={claim.id}>
              <td>{claim.id}</td>
              <td>{claim.policyNumber}</td>
              <td>{claim.policyHolderName}</td>
              <td>{claim.policyStartDate}</td>
              <td>{claim.policyEndDate}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ClaimsList;