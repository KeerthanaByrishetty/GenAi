import axios from 'axios';

const BASE_URL = 'http://localhost:8080/claims'; // Replace with your backend URL

export const getAllClaims = async () => {
  const response = await axios.get(`${BASE_URL}`);
  return response.data;
};

export const getPolicyDetails = async (policyNumber) => {
  const response = await axios.get(`${BASE_URL}/policies/${policyNumber}`);
  return response.data;
};